USE [DBSE]
GO
-- Пример выборки для представления DescriptorsView
SELECT
    *
FROM
    DescriptorsView;

-- Пример выборки для представления ApplicationsView
SELECT
    *
FROM
    ApplicationsView;

-- Пример выборки для представления PerforationsView
SELECT
    *
FROM
    PerforationsView;

-- Пример выборки для представления NormsView
SELECT
    *
FROM
    NormsView;

-- Пример выборки для представления MaterialsView
SELECT
    *
FROM
    MaterialsView;

-- Пример выборки для представления LoadDiagramsView
SELECT
    *
FROM
    LoadDiagramsView;

-- Пример выборки для представления GroupsApplicationsView
SELECT
    *
FROM
    GroupsApplicationsView;

-- Пример выборки для представления CoversView
SELECT
    *
FROM
    CoversView;

-- Пример выборки для представления ProductsView
SELECT
    *
FROM
    ProductsView;

-- Пример выборки для представления UnitsView
SELECT
    *
FROM
    UnitsView;

-- Пример выборки для представления ProductsVendorCodesView
SELECT
    *
FROM
    ProductsVendorCodesView;

-- Пример выборки для представления VendorCodesView
SELECT
    *
FROM
    VendorCodesView;

-- Пример выборки для представления ProductsAnalogsView
SELECT
    *
FROM
    ProductsAnalogsView;

-- Пример выборки для представления DescriptorsResourcesView
SELECT
    *
FROM
    DescriptorsResourcesView;

-- Пример выборки для представления ViewsTablesView
SELECT
    *
FROM
    ViewsTablesView;

-- Пример выборки для представления ViewTypesView
SELECT
    *
FROM
    ViewTypesView;

-- Пример выборки для представления ViewsView
SELECT
    *
FROM
    ViewsView;

-- Проверка остальных таблиц/предсталвений
SELECT
    *
FROM
    TablesView

SELECT
    *
FROM
    ViewsView

SELECT
    *
FROM
    ViewsTablesView
